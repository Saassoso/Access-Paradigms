---
title: Connect Git repos with Obsidian and personal account
status: open
priority: normal
scheduled: 2026-03-06
dateCreated: 2026-03-06T10:23:14.677+00:00
dateModified: 2026-03-06T11:09:39.682+00:00
tags:
  - task
timeEntries:
  - startTime: 2026-03-06T10:23:17.779Z
    description: Work session
    endTime: 2026-03-06T10:31:28.300Z
  - startTime: 2026-03-06T10:44:32.667Z
    description: Work session
    endTime: 2026-03-06T11:09:39.682Z
---

