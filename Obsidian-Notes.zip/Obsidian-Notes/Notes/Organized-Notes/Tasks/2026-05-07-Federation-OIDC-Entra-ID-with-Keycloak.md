---
date_created: 2026-05-07
date_completed: 
status: "pending"
tags: ["task", "phase-1", "identité", "federation", "entra", "Entra ID", "OIDC Flow", "SAML Federation"]
---

# Federation OIDC Entra ID with Keycloak

## Task Description
Enable users to connect to `auth.charif-labs.tech` with their `@ms.charif-labs.tech` accounts.

## Context
This task involves setting up a dual federation between Keycloak and Entra ID. This requires configuring an OIDC source within Keycloak to federate Microsoft identities and an Enterprise App SAML within Entra ID to federate towards Windows. The goal is to allow users to authenticate with their Microsoft accounts through Keycloak.

## Steps (Planned/Proposed)

### Step 1 — App Registration Entra ID (for Keycloak OIDC Source)
1. Entra Admin → App Registrations → New Registration
2. Name : `keycloak-oidc-source`
3. Redirect URI (Web) : `https://auth.charif-labs.tech/source/oauth/callback/entra/`
4. → Register

5. Copy : Application (client) ID
6. Certificates & Secrets → New client secret → copy value **immediately**

### Step 2 — OIDC Source in Keycloak
Keycloak → Directory → Federation & Social login → Create → Microsoft Entra ID (OIDC)
```
Name : entra-source
Consumer key : <Application ID of the App Registration>
Consumer secret : <Secret Value>
Tenant ID : <Directory ID of the tenant>
```
Test : "Login with Microsoft" button appears on auth.charif-labs.tech
→ Log in with `user@ms.charif-labs.tech`

### Step 3 — Enterprise App SAML in Entra (for Windows login)
1. Entra Admin → Enterprise Applications → New Application → Create your own
2. Name : `keycloak-saml-sp`
3. Single sign-on → SAML

4. Section "Basic SAML Configuration" :
   - Identifier (Entity ID) : `urn:charif-labs:keycloak`
   - Reply URL (ACS URL) : retrieve from Keycloak (SAML Provider → Metadata)

5. Download Certificate (Base64)

### Step 4 — Keycloak SAML Provider
Keycloak → Applications → Providers → Create → SAML Provider
```
Name : entra-saml-provider
ACS URL : URL of the Entra Enterprise App
Issuer : urn:charif-labs:keycloak
Signing Certificate : import the certificate downloaded from Entra
```

### Step 5 — End-to-End Test
```
1. Navigate to https://auth.charif-labs.tech
2. Click "Login with Microsoft"
3. Enter user@ms.charif-labs.tech + password
4. Consent → redirect to Keycloak
5. Active session in Keycloak ✅
```

### Debugging with SAML Tracer
Firefox/Chrome extension. Captures SAML assertions in real-time.
Elements to check:
- Matching Entity ID between IdP and SP
- Correct ACS URL
- Non-expired Assertion (`NotOnOrAfter`)
- Valid Signature (certificate imported on both sides)

## Outcome
[**USER INPUT REQUIRED**: This task is currently pending. Please update this section once the federation is successfully configured and tested.]

## Lessons Learned
[**USER INPUT REQUIRED**: Please describe any insights, challenges, or knowledge gained during this task's implementation.]

## Related Notes
- [[OIDC Flow]]
- [[SAML Federation]]
