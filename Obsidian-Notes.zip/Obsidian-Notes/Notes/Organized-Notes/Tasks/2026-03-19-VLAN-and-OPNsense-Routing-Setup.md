---
date_created: 2026-03-19
date_completed: 2026-03-19
status: "completed"
tags: ["task", "phase-0", "reseau", "opnsense", "Zenarmor", "VLAN Trunking 802.1Q", "Firewall Stateful"]
---

# VLAN and OPNsense Routing Setup

## Task Description
Implementation of zero-trust network segmentation.
Two VLANs on 802.1Q trunk (em1 interface of OPNsense).

## Context
This task involves setting up network segmentation with two VLANs on an 802.1Q trunk using OPNsense, specifically configuring VLAN 20 for endpoints and VLAN 30 for management, along with firewall rules and Zenarmor integration.

## Steps Taken

### 1. OPNsense VM Creation (VMware)
- 2 interfaces: NAT (em0/WAN) + LAN Segment (em1/Trunk)
- OPNsense OVA or ISO installed

### 2. OPNsense Initial Console Configuration
```
WAN → em0 (DHCP)
LAN → em1 (Trunk)

LAN IP : 10.0.30.1/29
DHCP on LAN : NO (Management network — restricted access)
```

Uncheck in Setup Wizard:
- Block RFC1918 Private Networks (WAN = NAT VMware = private IP)
- Optimize for Multiwan

### 3. VLAN 20 Creation (Endpoints)

OPNsense : Interfaces → Devices → VLAN → +
```
Parent : em1
Tag : 20
Description : VLAN20_Bureau
```

Interfaces → Assignments → Add VLAN20_Bureau → activate
IP : `10.0.20.1/24`, DHCP Kea enabled pool `10.0.20.100-199`

### 4. VLAN 30 (Management) = native em1 interface

The native LAN em1 interface is renamed VLAN30_Management.
IP already configured : `10.0.30.1/29`

> **Consistency Note** : VLAN ID 802.1Q = 30, IP network = 10.0.30.0/29. The network octet (10) ≠ VLAN ID (30). Do not confuse them.

### 5. Firewall Rules on VLAN20_Bureau

Firewall → Rules → VLAN20_Bureau

```
Rule 1 (BLOCK) :
  Action : Block
  Source : VLAN20_Bureau net
  Destination : LAN net (10.0.30.0/29)
  Description : ISOLATION zero-trust — Endpoints → Management

Rule 2 (PASS) :
  Action : Pass
  Source : VLAN20_Bureau net
  Destination : any
  Description : Internet access
```

### 6. Zenarmor

System → Firmware → Plugins → `os-sunnyvalley` → Install
Basic configuration applied.

## Outcome

| Test                 | Commande             | Résultat           |
| -------------------- | -------------------- | ------------------ |
| DHCP VLAN 20         | `ip a` sur namespace | IP 10.0.20.100-199 |
| Internet             | `ping 8.8.8.8`       | Réponse            |
| Isolation Management | `ping 10.0.30.2`     | 100% packet loss   |

## Lessons Learned
[**USER INPUT REQUIRED**: Please describe any insights, challenges, or knowledge gained during this task.]

## Related Notes
- [[Test isolation VLAN]]
- [[netplan]]
- [[Accès WebGUI OPNsense]]
