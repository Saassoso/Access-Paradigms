---
date_created: 2026-05-07
date_completed: 2026-05-07
status: "completed"
tags: ["task", "phase-0", "dns", "cloudflare", "terraform", "DNS Delegation", "Zero Trust Tunnel"]
---

# DNS and Cloudflare Setup

## Task Description
DNS delegation of `charif-labs.tech` to Cloudflare.
Provisioning of the ZTNA tunnel and CNAME records via Terraform.

## Context
This task involved delegating the `charif-labs.tech` domain to Cloudflare, provisioning a Zero Trust Network Access (ZTNA) tunnel, and configuring CNAME records using Terraform, followed by deploying `cloudflared` and Keycloak.

## Steps Taken

### 1. DNSSEC Deactivation (Tech Domains registrar)
Mandatory before changing NS to avoid cryptographic rejection.

### 2. Cloudflare Account Creation + Domain Import
Cloudflare → Add Site → charif-labs.tech
Cloudflare provides: `jasmine.ns.cloudflare.com` + `rohin.ns.cloudflare.com`

### 3. NS Replacement at Tech Domains
Old NS replaced by the two Cloudflare NS.
Propagation verified with:
```bash
nslookup -type=ns charif-labs.tech
```

### 4. Cloudflare API Token
Cloudflare → My Profile → API Tokens → Create Token
Permissions: Zone:DNS:Edit + Zone:Zone:Read

### 5. Terraform init + apply
```bash
export TF_VAR_cloudflare_api_token="..."
export TF_VAR_cloudflare_account_id="..."
export TF_VAR_cloudflare_zone_id="..."

cd terraform/
terraform init   # provider Cloudflare v4.52.5
terraform plan   # verify resources to create
terraform apply  # create tunnel + 4 CNAME + TXT Microsoft
```
Resources created:
- Tunnel `sovereign-stack-tunnel` (generated UUID)
- 4 proxified CNAMEs: auth, wazuh, trmm, n8n → `<uuid>.cfargotunnel.com`
- TXT `ms.charif-labs.tech` → `MS=ms76330167`

### 6. Retrieve tunnel token
```bash
terraform output -raw cloudflare_zero_trust_tunnel_cloudflared_token
# Store in docker/core-identity/cloudflared/.env
# TUNNEL_TOKEN=<value>
```

### 7. Deploy cloudflared
```bash
cd docker/
docker compose up -d cloudflared
docker compose logs cloudflared  # verify "Connected to Cloudflare"
```

### 8. Deploy keycloak
```bash
docker volume create keycloak_database
docker volume create keycloak_redis
cd docker/core-identity/
docker compose up -d
```
Verify: `https://auth.charif-labs.tech` → keycloak login page

## Outcome
- Tunnel `sovereign-stack-tunnel` created and active.
- DNS records (CNAMEs and TXT) propagated correctly, verified via `dig` and `nslookup`.
- Keycloak accessible via `https://auth.charif-labs.tech`.
- Domain `charif-labs.tech` successfully verified in Entra ID.

## Lessons Learned
[**USER INPUT REQUIRED**: Please describe any insights, challenges, or knowledge gained during this task.]

## Related Notes
- [[DNS Delegation]]
- [[Zero Trust Tunnel]]
