---
date_created: 2026-03-19
date_completed: 2026-03-19
status: "completed"
tags: ["task", "lab", "reseau", "validation", "vlan", "OPNsense", "Network Namespaces Linux", "VLAN Trunking 802.1Q"]
---

# Test Isolation VLAN

## Task Description
Validate OPNsense firewall rules without needing a dedicated Windows VM. Uses [[Network Namespaces Linux]] from the Docker Host to simulate a VLAN 20 client.

## Context
This task involves simulating a client on VLAN 20 using Linux Network Namespaces on the Docker Host to test firewall rules configured in OPNsense.

## Steps Taken
1. Install isc-dhcp-client:
   ```bash
   sudo apt install isc-dhcp-client -y
   ```
2. Create the namespace + VLAN 20 interface:
   ```bash
   sudo ip netns add client_bureau
   sudo ip link add link ens33 name vlan20 type vlan id 20
   ```
3. Force the same MAC (necessary with VMware):
   ```bash
   MAC=$(ip link show ens33 | awk '/ether/ {print $2}')
   sudo ip link set vlan20 netns client_bureau
   sudo ip netns exec client_bureau ip link set vlan20 address $MAC
   ```
4. Activate the interfaces:
   ```bash
   sudo ip netns exec client_bureau ip link set lo up
   sudo ip netns exec client_bureau ip link set vlan20 up
   ```
5. Obtain a DHCP IP:
   ```bash
   sudo ip netns exec client_bureau dhclient -v vlan20
   ```

## Tools Used
- OPNsense
- ip command (Linux)
- dhclient (Linux)
- awk (Linux)
- ping (Linux)

## Outcome
| Test                 | Attendu      | Obtenu       | Statut |
| -------------------- | ------------ | ------------ | ------ |
| DHCP VLAN 20         | IP 10.0.20.x | 10.0.20.100  | Done   |
| Internet             | Réponse ping | 4/4 réponses | Done   |
| Isolation Management | 0% réponse   | 100% loss    | Done   |

## Lessons Learned
[**USER INPUT REQUIRED**: Please describe any insights, challenges, or knowledge gained during this task.]

## Related Notes
- [[Network Namespaces Linux]]
- [[VLAN Trunking 802.1Q]]
