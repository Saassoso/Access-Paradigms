---
date_created: {{date}}
date_completed: 
status: "completed" # "pending", "in_progress", "completed", "cancelled"
tags: ["task"]
---

# {{title}}

## Task Description
[Detailed description of the task goes here.]

## Context
[Any relevant background or context for the task.]

## Steps Taken
- [Step 1]
- [Step 2]
- ...

## Tools Used
- [Tool 1]
- [Tool 2]
- ...

## Outcome
[Summary of the results and achievements of the task.]

## Lessons Learned
[Any insights, challenges, or knowledge gained during the task.]

## Related Notes
- [[Link to another note]]
- [URL to external resource](URL)
