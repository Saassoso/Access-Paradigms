---
date_created: 2026-05-07
date_completed: 2026-05-07
status: "completed"
tags: ["task", "phase-1", "identité", "Docker", "OIDC Flow", "SAML Federation"]
---

# Keycloak Deployment and Initial Setup

## Task Description
Deployment of the central IdP.
Keycloak replaces Workspace and Entra as an identity provider.

## Context
This task involved deploying Keycloak as the central Identity Provider, replacing existing solutions, and configuring its initial organizational structure including groups, users, and organizational units.

## Steps Taken

### 1. Environment Variables
```bash
# docker/core-identity/keyclaok/.env
# (Specific environment variables for Keycloak configuration go here)
```

### 2. Docker Compose
```bash
cd docker/core-identity/
docker compose up -d
docker compose ps  # all healthy
```

### 3. Initial Admin Setup
URL : `https://auth.charif-labs.tech/if/flow/initial-setup/`
Admin account : `akadmin` + strong password

### 4. Organizational Structure
Keycloak → Directory → Groups → Create
```
Group: basique    (VLAN 20 Bureau 1 users)
Group: admins     (VLAN 20 Bureau 2 users)
```
Keycloak → Directory → Users → Create (3 users)
- `user-basic-01` → group basique
- `user-admin-01` → group admins
- `breakglass` → group admins (emergency account)

- Create Roles
  - Admins
  - Bureau 1
  - Bureau 2
  - OU
  - Standard User
  - root
- Organizational Units (Folders)
  - Folder : `Bureau1`
  - Folder : `Bureau2`
  - The third existing one `keycloak admins`
- Groups
  - Group : `basique` (Attached to OU `Bureau1`)
  - Group : `admins` (Attached to OU `Bureau2`)
- Users (Identities)
  - user-basic-01 : GP= `basique`, Dir= Bureau1, Rules=
  - user-admin-01 : GP= `admins`, Dir=Bureau2, Rules=
  - breakglass : GP= `admins`, Dir=Bureau2, Rules=
  - akadmin : GP= keycloak Admins, Dir= users, Roles=

## Outcome
- Keycloak successfully deployed via Docker Compose.
- Initial admin account (`akadmin`) created.
- Organizational structure (groups, users, and OUs/Folders) configured within Keycloak to segment users based on their roles and VLAN assignments.

## Lessons Learned
[**USER INPUT REQUIRED**: Please describe any insights, challenges, or knowledge gained during this task.]

## Related Notes
- [[OIDC Flow]]
- [[SAML Federation]]
- [[2 - Federation OIDC Entra ID]]
